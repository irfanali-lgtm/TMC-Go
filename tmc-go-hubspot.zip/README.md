# TMC Go on HubSpot

Two ways. Both need the backend first (paste `Code.gs` into the sheet's Apps Script → Deploy → New version → copy the `/exec` link).

## A · As a HubSpot page (recommended — your own domain, e.g. go.tmcltd.com/tmc-go)
1. HubSpot → **Content → Design Manager** → **File → New file → HTML & HubL → Page template** (or "Coded file") → name it `tmc-go`.
2. Delete the generated content, paste the whole of `tmc-go.html`, **Publish changes**.
3. **Content → Website Pages → Create → Website page** → choose the *TMC Go* template → page title "TMC Go" → set the URL slug → **Publish**.
Before step 2's Publish: on line 6 of the template, paste your `/exec` link between the quotes of `tmc_backend`. That's the only edit — the page then opens straight to the name picker for everyone, no connect screen.
4. Open the page URL and share it.

The template wraps the app in `{% raw %}` so HubL leaves the code alone, and includes `standard_header_includes` / `standard_footer_includes` as HubSpot requires.

## B · As a hosted file (quickest)
Content → Files → **Upload** `index.html` → open the file → **Copy URL** → share. Same app, HubSpot CDN address instead of your domain.

## Notes
- No build step, no environment variables; the Gemini and Maps keys stay in the Google Sheet.
- Voice and location work (the page is served top-level, not framed).
- Updating: paste the new `tmc-go.html` over the template and Publish changes (A), or re-upload `index.html` (B).
- HubSpot's cookie banner, if enabled for the domain, appears on this page like any other; it does not interfere.
